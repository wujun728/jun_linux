#!/bin/bash
ROOT=$(pwd)
SCRIPTS=$ROOT/scripts
PKGS=$ROOT/pkgs


#tar -zxvf libwww-perl-5.837.tar.gz -C $PKGS

cd /$PKGS/libwww-perl-5.837

perl ./Makefile.PL  && make && make install 

cp $SCRIPTS/sendsmspost.pl  /usr/local/bin/

cd /usr/local/bin/  

chmod 755 sendsmspost.pl
mkdir -p /data/log/zabbix/

perl sendsmspost.pl

res=$? 

if [[   $res -eq 0    ]] ;then 
echo -e  "\033[44m 短信脚本安装成功!! \033[0m"
echo   "短信脚本的文件为:   /usr/local/bin/sendsmspost.pl "
echo   "请修改上述文件的相关短信网关配置!"
else 
echo -e   "\033[41m 短信脚本安装失败!! \033[0m" 
fi 




