- 项目参考 bootdo的gen模块 和  gen
- 因为bootdo是针对mysql进行代码一键生成，本人在项目中使用的是oracle，所以稍微修改了一下生成方法，以及适合公司项目的生成模版

- 将代码生成抽成一个controller，将项目打成jar包直接运行即可
运行说明:
![访问//common/generator路径](https://gitee.com/uploads/images/2018/0515/152647_d1247d27_1308248.png "屏幕截图.png")

- 生成策略修改代码生成的包名:
![参数配置](https://gitee.com/uploads/images/2018/0515/152734_52276bf6_1308248.png "屏幕截图.png")

- 项目配置好了双数据源 所以只要修改dev.yml文件 配置数据源即可直接使用
![参数配置](https://gitee.com/uploads/images/2018/0515/152920_50aa656d_1308248.png "屏幕截图.png")

- 可按照自己需求修改，修改文件
![修改文件](https://gitee.com/uploads/images/2018/0515/153013_63fb997f_1308248.png "屏幕截图.png")
这两个文件基本就是代码生成的核心了
