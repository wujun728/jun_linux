package com.example.demo.config;

public class Constant {
    //自动去除表前缀
    public static String AUTO_REOMVE_PRE = "true";
}
