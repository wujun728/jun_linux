package com.example.demo.service.imp;

import com.example.demo.dao.mysql.GeneratorMapper;
import com.example.demo.dao.oracle.OracleGeneratorMapper;
import com.example.demo.service.GeneratorService;
import com.example.demo.util.GenUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;


@Service
public class GeneratorServiceImpl implements GeneratorService {
	@Autowired
	OracleGeneratorMapper oracleGeneratorMapper;

	@Autowired
	GeneratorMapper generatorMapper;

	@Override
	public List<Map<String, Object>> list() {
		List<Map<String, Object>> list = oracleGeneratorMapper.list();
		return list;
	}

	@Override
	public List<Map<String, Object>> listMysql() {
		return generatorMapper.list();
	}

	@Override
	public byte[] generatorCode(String[] tableNames,String dataType) throws Exception {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		if(StringUtils.isEmpty(dataType))dataType="mysql";
		ZipOutputStream zip = new ZipOutputStream(outputStream);
		for(String tableName : tableNames){
			//查询表信息
			Map<String, String> table = oracleGeneratorMapper.get(tableName);

			//查询列信息
			List<Map<String, String>> columns = oracleGeneratorMapper.listColumns(tableName);
			//生成代码
			GenUtils.generatorCode(table, columns, zip);
		}
		IOUtils.closeQuietly(zip);
		return outputStream.toByteArray();
	}

}
